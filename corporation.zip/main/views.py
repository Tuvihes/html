from .models import Примечание
from django.shortcuts import render


def index(request):
    tasks = Примечание.objects.order_by('-id')
    return render(request,'main/index.html', {'title':'Главная страница сайта','tasks':tasks})


def about(request):
    return render(request, 'main/about.html')


def lilok(request):
    return render(request, 'main/lilok.html')




