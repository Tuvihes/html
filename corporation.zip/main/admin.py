from django.contrib import admin
from .models import Примечание


admin.site.register(Примечание)
