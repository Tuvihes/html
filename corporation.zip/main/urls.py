from django.urls import path
from.import views

urlpatterns = [
    path('',views.index, name='home'),
    path('corp', views.about, name='about'),
    path('lilok', views.lilok, name='lilok'),
]
